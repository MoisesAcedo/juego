export class Tablero {
    constructor(

        public celdas: number,
        public pozos: number,
        public flechas: number
        

    ){}
}